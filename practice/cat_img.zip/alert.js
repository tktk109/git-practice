function loadHello(){
    alert("Hello!");
  }
  
  function sum(){
    let x = 3;
    let y = 4;
    let z = x + y;
    alert(z);
  }